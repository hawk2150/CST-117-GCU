﻿//Chris Hawkins
//CST-117, Exercise 4
//Prof. Smithers
//9-02-2018
//This is my own work

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercise4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            
                double seconds;
                double minutes;
                double hours;
                double days;

                seconds = double.Parse(textBox1.Text);//parse user input from text box to perform calculations

            if (seconds > 0)
            {

                if (seconds < 60)
                {
                    answerLabel.Text = seconds.ToString();      //Shows seconds inputted by user
                }



                else if (seconds <= 3599)
                {
                    minutes = (seconds / 60);
                    answerLabel.Text = minutes.ToString("n2"); //Display seconds in minutes 
                    minLabel.Visible = true;    //This section of code ensures correct unit label is used and viewable
                    hrsLabel.Visible = false;
                    dayLabel.Visible = false;
                }


                else  
                {
                    if (seconds < 86400 || seconds >= 3600)     //Display seconds in hours
                    {
                        hours = (seconds / 3600);
                        answerLabel.Text = hours.ToString("n2");
                        hrsLabel.Visible = true;
                        minLabel.Visible = false;       //This section of code ensures correct unit label is used and viewable
                        dayLabel.Visible = false;
                    }
                    if (seconds >= 86400)
                    {
                        days = (seconds / 86400);
                        answerLabel.Text = days.ToString("n2");     //Display seconds in days
                        dayLabel.Visible = true;
                        hrsLabel.Visible = false;       //This section of code ensures correct unit label is used and viewable
                        minLabel.Visible = false;
                    }

                }

                


            }

          
        }

        
    }
}
